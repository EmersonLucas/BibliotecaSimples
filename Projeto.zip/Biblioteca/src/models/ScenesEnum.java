package models;

public enum ScenesEnum {
	PRESENTATION, LOGIN, REGISTRATION, CLIENT, EMPLOYEE;
}
