package infra;

import models.MyBooks;

public class MyBooksDAO extends DAO<MyBooks> {
	public MyBooksDAO() {
		super(MyBooks.class);
	}
}
